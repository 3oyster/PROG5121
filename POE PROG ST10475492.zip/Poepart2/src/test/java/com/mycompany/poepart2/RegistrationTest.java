/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.poepart2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_Lab
 */
public class RegistrationTest {
    
    public RegistrationTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of userNameCheck method, of class Registration.
     */
    @Test
    public void testUserNameCheck() {
        System.out.println("userNameCheck");
        String username = "";
        Registration instance = new Registration();
        boolean expResult = false;
        boolean result = instance.userNameCheck(username);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
      
    }

    /**
     * Test of passwordCheck method, of class Registration.
     */
    @Test
    public void testPasswordCheck() {
        System.out.println("passwordCheck");
        String password = "";
        Registration instance = new Registration();
        boolean expResult = false;
        boolean result = instance.passwordCheck(password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of cellNumberCheck method, of class Registration.
     */
    @Test
    public void testCellNumberCheck() {
        System.out.println("cellNumberCheck");
        String cellphone = "+27834557896";
        Registration instance = new Registration();
        boolean expResult = false;
        boolean result = instance.cellNumberCheck(cellphone);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       
    }

    /**
     * Test of signUp method, of class Registration.
     */
    @Test
    public void testSignUp() {
        System.out.println("signUp");
        Registration instance = new Registration();
        instance.signUp();
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of signIn method, of class Registration.
     */
    @Test
    public void testSignIn() {
        System.out.println("signIn");
        Registration instance = new Registration();
        instance.signIn();
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of sendMessage method, of class Registration.
     */
    @Test
    public void testSendMessage() {
        System.out.println("sendMessage");
        Registration instance = new Registration();
        instance.sendMessage();
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of checkMessageId method, of class Registration.
     */
    @Test
    public void testCheckMessageId() {
        System.out.println("checkMessageId");
        Registration instance = new Registration();
        String expResult = "";
        String result = instance.checkMessageId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of createMessageHash method, of class Registration.
     */
    @Test
    public void testCreateMessageHash() {
        System.out.println("createMessageHash");
        String messageId = "";
        int messageNum = 0;
        String messageContent = "";
        Registration instance = new Registration();
        String expResult = "";
        String result = instance.createMessageHash(messageId, messageNum, messageContent);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of returnTotalMessages method, of class Registration.
     */
    @Test
    public void testReturnTotalMessages() {
        System.out.println("returnTotalMessages");
        Registration instance = new Registration();
        int expResult = 0;
        int result = instance.returnTotalMessages();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of printMessages method, of class Registration.
     */
    @Test
    public void testPrintMessages() {
        System.out.println("printMessages");
        Registration instance = new Registration();
        String expResult = "";
        String result = instance.printMessages();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of messageManagement method, of class Registration.
     */
    @Test
    public void testMessageManagement() {
        System.out.println("messageManagement");
        Registration instance = new Registration();
        instance.messageManagement();
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of searchById method, of class Registration.
     */
    @Test
    public void testSearchById() {
        System.out.println("searchById");
        Registration instance = new Registration();
        instance.searchById();
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of searchByHeading method, of class Registration.
     */
    @Test
    public void testSearchByHeading() {
        System.out.println("searchByHeading");
        Registration instance = new Registration();
        instance.searchByHeading();
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of reportByRecipient method, of class Registration.
     */
    @Test
    public void testReportByRecipient() {
        System.out.println("reportByRecipient");
        Registration instance = new Registration();
        instance.reportByRecipient();
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of printMessage method, of class Registration.
     */
    @Test
    public void testPrintMessage() {
        System.out.println("printMessage");
        Registration instance = new Registration();
        instance.printMessage();
        
    }

    /**
     * Test of deleteByHash method, of class Registration.
     */
    @Test
    public void testDeleteByHash() {
        System.out.println("deleteByHash");
        Registration instance = new Registration();
        instance.deleteByHash();
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of displayLongestMessage method, of class Registration.
     */
    @Test
    public void testDisplayLongestMessage() {
        System.out.println("displayLongestMessage");
        Registration instance = new Registration();
        instance.displayLongestMessage();

    }

    /**
     * Test of generateMessageId method, of class Registration.
     */
    @Test
    public void testGenerateMessageId() {
        System.out.println("generateMessageId");
        Registration instance = new Registration();
        String expResult = "";
        String result = instance.generateMessageId();
        assertEquals(expResult, result);

    }
    
}
